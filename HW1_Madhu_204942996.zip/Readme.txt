Name: Madhu Kolli (MSOL)
UCLA ID : 204 992996
Details of Submission:
1) Latex PDF report on findings for Logistic regression and SVM classifier
2) Python file - HW1_Madhu_204942996.py
3) Instructions to run program -
   a) Run python program - python HW1_Madhu_204942996.py
   b) Data is downloaded and the program automatically runs logistic regression and SVM classifier 
   and dispalys step wise epoch,average loss and overally accuracy.
   b) Alter Learning rates and momentum to saving varying loss and accuracy    results.