#!/usr/bin/env python
# coding: utf-8

# In[8]:


#Don't change batch size
args={}
kwargs={}
args['batch_size']=64
args['cuda']=False
args['epochs']=10  #The number of Epochs is the number of times you go through the full dataset. 
args['learning_rate'] = 0.2 #Learning rate is how fast it will decend. 
args['momentum'] = 0 #SGD momentum (default: 0.5) Momentum is a moving average of our gradients (helps to keep direction).


input_size = 784
num_classes = 1


import torch
import torch.nn as nn
from torch.autograd import Variable
from torchvision import datasets, transforms, utils
from torch.utils.data.sampler import SubsetRandomSampler
from torch.nn import functional as F

## USE THIS SNIPPET TO GET BINARY TRAIN/TEST DATA

train_data = datasets.MNIST('./data/madhu/pytorch/data/', train=True, download=True,
                   transform=transforms.Compose([
                       transforms.ToTensor(),
                       transforms.Normalize((0.1307,), (0.3081,))
                   ]))
test_data = datasets.MNIST('./data/madhu/pytorch/data/', train=False, download=True,
                   transform=transforms.Compose([
                       transforms.ToTensor(),
                       transforms.Normalize((0.1307,), (0.3081,))
                   ]))

subset_indices = ((train_data.train_labels == 0) + (train_data.train_labels == 1)).nonzero().view(-1)

train_loader = torch.utils.data.DataLoader(dataset=train_data, 
                                           batch_size=args['batch_size'], 
                                           shuffle=False,
                                           sampler=SubsetRandomSampler(subset_indices))

subset_indices = ((test_data.test_labels == 0) + (test_data.test_labels == 1)).nonzero().view(-1)

test_loader = torch.utils.data.DataLoader(dataset=test_data, 
                                          batch_size=args['batch_size'],
                                          shuffle=False,
                                          sampler=SubsetRandomSampler(subset_indices))


# In[9]:


# Custom Loss and Logistic Regression Model
class Regress_Loss(nn.modules.Module):    
    def __init__(self):
        super(Regress_Loss,self).__init__()
    def forward(self, outputs, labels):
        #multi = 0
        loss = 0
        args['batch_size'] = outputs.size()[0]

        for x in range(args['batch_size']): 
            loss += torch.log(1 + torch.exp(-(outputs[x]*labels[x])))/args['batch_size']
 
        return loss

#Logistic regression model 
model = nn.Linear(input_size,num_classes)

# Loss criteria and SGD optimizer
loss_criteria = Regress_Loss()
optimizer = torch.optim.SGD(model.parameters(), lr=args['learning_rate'],momentum = args['momentum'] )
#scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)


# In[10]:


# Train the model
total_step = len(train_loader)
n = 0 
for epoch in range(args['epochs']):
    avg_loss = 0
    sumloss = 0
    n = 0
    for i, (images, labels) in enumerate(train_loader):
        # Reshape images to (batch_size, input_size)
        images = images.reshape(-1, 28*28) 
        #Conver#t labels from 0,1 to -1,1
              
        labels = Variable(2*(labels.float()-0.5))
        outputs = model(images)       
        loss = loss_criteria(outputs, labels)    
        #print(learning_rate)
               
        # Backward and optimize
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        #scheduler.step()
        n +=1
        
        sumloss += loss
  
    avg_loss = sumloss/n
    print ('Epoch [{}/{}], Step [{}/{}],Loss: {:.4f},Avg Loss' 
                  .format(epoch+1, args['epochs'], i+1, total_step, loss.item()),avg_loss)           
   


# In[11]:


# Test the Model
correct = 0.
total = 0.
for images, labels in test_loader:
        images = images.reshape(-1, 28*28)
        #labels = Variable(2*(labels.float()-0.5))
        outputs = torch.sigmoid(model(images))
        predicted = outputs.data >= 0.5 
        total += labels.size(0) 
        correct += (predicted.view(-1).long() == labels).sum()
        #correct += (prediction.view(-1).long() == labels).sum()

print('Accuracy of the model on the test images: %f %%' % (100 * (correct.float() / total)))


# In[12]:


#Part 2 HW1 - SVM Loss model
class SVM_Loss(nn.modules.Module):    
    def __init__(self):
        super(SVM_Loss,self).__init__()
    def forward(self, outputs, labels):
        loss =0
        loss_sum = 0
        loss_sum = torch.sum(torch.clamp(1 - outputs*labels, min=0))
        loss = loss_sum/args['batch_size'] 
        return loss

#Logistic regression model and Loss
svm_model = nn.Linear(input_size,num_classes)

## Loss criteria and SGD optimizer
svm_loss_criteria = SVM_Loss()
svm_optimizer = torch.optim.SGD(svm_model.parameters(), lr=args['learning_rate'],momentum = args['momentum'])
total_step = len(train_loader)


# In[13]:


# Train the SVM Model
s = 0 
for epoch in range(args['epochs']):
    s = 0
    avgsvm_loss = 0
    svmloss = 0
    for i, (images, labels) in enumerate(train_loader):
        # Reshape images to (batch_size, input_size)
        images = images.reshape(-1, 28*28) 
        #Conver#t labels from 0,1 to -1,1
        labels = Variable(2*(labels.float()-0.5))
        outputs = svm_model(images)
        loss_svm = svm_loss_criteria(outputs.view(-1), labels)    
        
        #loss = loss_criteria(outputs, labels) 
        
        # Backward and optimize
        svm_optimizer.zero_grad()
        loss_svm.backward()
        svm_optimizer.step()
        s +=1
        svmloss += loss_svm
        
    avgsvm_loss = svmloss/s
        
    print ('Epoch [{}/{}], Step [{}/{}], Loss: {:.4f},Avg Loss' 
                   .format(epoch+1,args['epochs'], i+1, total_step, loss_svm.item()),avgsvm_loss)


# In[14]:


# Test the SVM Model
correct = 0.
total = 0.
for images, labels in test_loader:
    images = images.reshape(-1, 28*28)
    #labels = Variable(2*(labels.float()-0.5))
    outputs = svm_model(images)
    predicted = outputs.data >= 0 
    total += labels.size(0) 
    correct += (predicted.view(-1).long() == labels).sum()
   
print('Accuracy of the model on the test images: %f %%' % (100 * (correct.float() / total)))


# In[ ]:




